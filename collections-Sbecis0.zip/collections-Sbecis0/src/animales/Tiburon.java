package animalitos;

public class Tiburon extends Pez {
    public Tiburon(String nombre) {
        super(nombre);
        setSpecie("Tiburon");
    }
    public void aletear(){
        System.out.println("Literalmente nado bro");
    }


}
