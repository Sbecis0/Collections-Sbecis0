public class Sample {
    public static int suma(int a, int b){
        return a + b;
    }
}
