Corrección: OK
